package dat.config;

import dat.dtos.GuideDTO;
import dat.entities.Guide;
import dat.entities.Trip;
import dat.enums.Category;
import jakarta.persistence.EntityManagerFactory;
import org.jetbrains.annotations.NotNull;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Populate {

    public static void populate() {
        EntityManagerFactory emf = HibernateConfig.getEntityManagerFactory("guidetrip");

        try (var em = emf.createEntityManager()) {
            em.getTransaction().begin();

            // Create guides and trips
            Set<Guide> guides = getGuides();

            // Persist guides
            for (Guide guide : guides) {
                em.persist(guide);
            }

            em.getTransaction().commit();
        }
    }

    @NotNull
    private static Set<Guide> getGuides() {
        Guide g1 = new Guide("John", "Doe", "john.doe@example.com", 12345678, 10);
        Guide g2 = new Guide("Jane", "Smith", "jane.smith@example.com", 98765432, 8);
        Guide g3 = new Guide("Emily", "Brown", "emily.brown@example.com", 45612378, 5);

        // Assign specific trips to each guide
        Set<Trip> allTrips = getTrips();
        g1.setTrips(new HashSet<>(allTrips.stream().limit(2).toList()));
        g2.setTrips(new HashSet<>(allTrips.stream().skip(2).limit(2).toList()));
        g3.setTrips(new HashSet<>(allTrips.stream().skip(4).limit(2).toList()));

        Set<Guide> guides = new HashSet<>();
        guides.add(g1);
        guides.add(g2);
        guides.add(g3);

        return guides;
    }

    @NotNull
    private static Set<Trip> getTrips() {
        Set<Trip> trips = new HashSet<>();
        trips.add(new Trip("Sunny Beach", Category.BEACH, 45.0, LocalDate.now().plusDays(1), LocalDate.now().plusDays(1), "Golden Sands"));
        trips.add(new Trip("Downtown Exploration", Category.CITY, 30.0, LocalDate.now().plusDays(2), LocalDate.now().plusDays(2), "City Center"));
        trips.add(new Trip("Forest Trekking", Category.FOREST, 35.0, LocalDate.now().plusDays(3), LocalDate.now().plusDays(3), "Evergreen Woods"));
        trips.add(new Trip("Lake Camp", Category.LAKE, 40.0, LocalDate.now().plusDays(4), LocalDate.now().plusDays(4), "Crystal Lake"));
        trips.add(new Trip("Sea Cruise", Category.SEA, 60.0, LocalDate.now().plusDays(5), LocalDate.now().plusDays(5), "Blue Horizon Port"));
        trips.add(new Trip("Snowy Adventure", Category.SNOW, 70.0, LocalDate.now().plusDays(6), LocalDate.now().plusDays(6), "White Peaks"));

        return trips;
    }
}
