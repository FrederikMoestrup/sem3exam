package dat.services;

import com.fasterxml.jackson.annotation.JsonProperty;
import dat.dtos.TripDTO;

import java.util.List;

public class TripResponse {
    @JsonProperty("results")
    private List<TripDTO> results;

    public List<TripDTO> getTrips() {
        return results;
    }
}
