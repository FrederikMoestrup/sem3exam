package dat.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import dat.dtos.TripDTO;
import dat.services.TripResponse; // Assuming you have a TripResponse class similar to MovieResponse
import dat.entities.Trip;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class TripService {
    private static String BASE_URL_SEARCH = "https://packingapi.cphbusinessapps.dk/packinglist";
    private static String ADDITIONAL_URL_PARAMS = "/beach";
    private ObjectMapper objectMapper = new ObjectMapper();

    public TripService() {
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.registerModule(new JavaTimeModule());
    }

    public List<TripDTO> getTrips() {
        List<TripDTO> allTrips = new ArrayList<>();
        int page = 1;
        boolean morePages = true;

        HttpClient client = HttpClient.newHttpClient();

        try {
            while (morePages) {
                String url = BASE_URL_SEARCH + ADDITIONAL_URL_PARAMS;
                HttpRequest request = HttpRequest
                        .newBuilder()
                        .uri(java.net.URI.create(url))
                        .build();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                if (response.statusCode() == HttpURLConnection.HTTP_OK) {
                    dat.services.TripResponse tripResponse = objectMapper.readValue(response.body(), TripResponse.class);
                    List<TripDTO> tripInfoList = tripResponse.getTrips(); // Assuming TripResponse has a getTrips() method

                    if (tripInfoList != null && !tripInfoList.isEmpty()) {
                        allTrips.addAll(tripInfoList);
                        page++;
                    } else {
                        morePages = false;
                    }
                } else {
                    throw new IOException("Failed to fetch data from API. HTTP status code: " + response.statusCode());
                }
            }

            if (allTrips.isEmpty()) {
                throw new IOException("No trip information found.");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        return allTrips;
    }

    public List<String> convertTripsToJson(List<Trip> trips) throws JsonProcessingException {
        List<String> json = new ArrayList<>();
        for (Trip trip : trips) {
            json.add(objectMapper.writeValueAsString(trip));
        }
        return json;
    }
}
