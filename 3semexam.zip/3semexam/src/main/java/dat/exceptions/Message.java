package dat.exceptions;

public record Message(int status, String message) {
}
