package dat.controllers;
import dat.config.ApplicationConfig;
import dat.config.HibernateConfig;

import dat.dtos.TripDTO;
import dat.dtos.TripGuideResponseDTO;
import dat.entities.Guide;
import dat.entities.Trip;
import dat.enums.Category;
import dat.security.controllers.SecurityController;
import dat.security.daos.SecurityDAO;
import dat.security.exceptions.ValidationException;
import dk.bugelhartmann.UserDTO;
import io.javalin.Javalin;
import io.restassured.common.mapper.TypeRef;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import org.junit.jupiter.api.*;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;



@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class TripControllerTest {

    private final static EntityManagerFactory emf = HibernateConfig.getEntityManagerFactoryForTest();
    private final static SecurityController securityController = SecurityController.getInstanceForTest(emf);
    private final static SecurityDAO securityDAO = securityController.getSecurityDAO();
    private static Javalin app;
    private static Set<Guide> guides;
    private static Set<Trip> trips;
    private static UserDTO userDTO, adminDTO;
    private static String userToken, adminToken;
    private static final String BASE_URL = "http://localhost:7070/api";

    @BeforeAll
    void setUpAll() {
        HibernateConfig.setTest(true);
        // Start api
        app = ApplicationConfig.startServer(7070);
    }

    @BeforeEach
    void setUp() {
        // Populate the database with hotels and rooms
        System.out.println("Populating database with trips and guides");
        guides = Populator.populateGuide(emf);
        trips = Populator.populateTrips(emf);
        UserDTO[] users = Populator.populateUsers(emf);
        userDTO = users[0];
        adminDTO = users[1];

        try {
            UserDTO verifiedUser = securityDAO.getVerifiedUser(userDTO.getUsername(), userDTO.getPassword());
            UserDTO verifiedAdmin = securityDAO.getVerifiedUser(adminDTO.getUsername(), adminDTO.getPassword());
            userToken = "Bearer " + securityController.createToken(verifiedUser);
            adminToken = "Bearer " + securityController.createToken(verifiedAdmin);
        }
        catch (ValidationException e) {
            throw new RuntimeException(e);
        }
    }

    @AfterEach
    void tearDown() {
        try (EntityManager em = emf.createEntityManager()) {
            em.getTransaction().begin();
            em.createQuery("DELETE FROM User").executeUpdate();
            em.createQuery("DELETE FROM Role").executeUpdate();
            em.createQuery("DELETE FROM Trip").executeUpdate();
            em.createQuery("DELETE FROM Guide").executeUpdate();
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @AfterAll
    void tearDownAll() {
        ApplicationConfig.stopServer(app);
    }

    @Test
    void getAll() {
        System.out.println("usertoken: " + userToken);
        System.out.println("admintoken: " + adminToken);
        List<TripDTO> tripDTO =
                given()
                        .when()
                        .header("Authorization", userToken)
                        .get(BASE_URL + "/trips")
                        .then()
                        .statusCode(200)
                        .body("size()", is(6))
                        .log().all()
                        .extract()
                        .as(new TypeRef<List<TripDTO>>() {});

        assertThat(tripDTO.size(), is(6));
    }

    //Denne her kunne jeg ikke lige få til at virke
    @Test
    void getById() {
        TripGuideResponseDTO tripGuideResponseDTO =
                given()
                        .when()
                        .header("Authorization", userToken)
                        .get(BASE_URL + "/trips/1")
                        .then()
                        .statusCode(200)
                        .log().all()
                        .extract()
                        .as(TripGuideResponseDTO.class);

        assertThat(tripGuideResponseDTO.getTrip().getName(), is("Sunny Beach"));
    }


    @Test
    void create() {
        TripDTO tripDTO = new TripDTO("Sunny Beach 2", Category.BEACH, 45.0, LocalDate.now().plusDays(1), LocalDate.now().plusDays(1), "Golden Sands");
        TripDTO responseTripDTO =
                given()
                        .when()
                        .header("Authorization", adminToken)
                        .body(tripDTO)
                        .post(BASE_URL + "/trips")
                        .then()
                        .statusCode(201)
                        .log().all()
                        .extract()
                        .as(TripDTO.class);

        assertThat(responseTripDTO.getName(), is("Sunny Beach 2"));
    }

    @Test
    void delete() {
        TripDTO tripDTO =
                given()
                        .when()
                        .header("Authorization", adminToken)
                        .delete(BASE_URL + "/trips/1")
                        .then()
                        .statusCode(200)
                        .log().all()
                        .extract()
                        .as(TripDTO.class);
        assertThat(tripDTO.getName(), is("Sunny Beach"));
    }

}